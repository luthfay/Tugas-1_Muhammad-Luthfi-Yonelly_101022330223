# My First Project > 2025-06-13 1:22pm
https://universe.roboflow.com/tugas-imv/my-first-project-oz54d-o7fzl

Provided by a Roboflow user
License: CC BY 4.0

